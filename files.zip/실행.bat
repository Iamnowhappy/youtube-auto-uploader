@echo off
chcp 65001 > nul
title YouTube 자동화 관리자

echo.
echo  ================================================
echo   YouTube 자동화 관리자 시작 중...
echo  ================================================
echo.

cd /d "%~dp0"

:: Python 경로
set PYTHON=C:\Users\gichang\AppData\Local\Programs\Python\Python312\python.exe

:: 라이브러리 자동 설치 (없으면)
echo  필요 라이브러리 확인 중...
%PYTHON% -c "import gspread, dropbox, requests" 2>nul
if errorlevel 1 (
    echo  라이브러리 설치 중...
    %PYTHON% -m pip install requests gspread google-auth google-api-python-client dropbox --quiet
    echo  설치 완료!
)

echo.
echo  UI 실행 중...
%PYTHON% youtube_manager_ui.py

if errorlevel 1 (
    echo.
    echo  ❌ 오류 발생. 엔터를 눌러 종료하세요.
    pause > nul
)
